namespace StudyTests.Models.Entities;

public class Teacher: User
{
    
}