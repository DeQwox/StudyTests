namespace StudyTests.Models.Entities;

public class Student: User
{
    
}